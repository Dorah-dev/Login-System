# login-system
A signup page where user can register and a login page to login with the details provided during registration
sucessful login redirects to user dash page which shows aditional details provided during registration and user can update his persional details like contacts
bootstrap is used to make page responsive
jquery is used to simplify DOM manipulations
user data stored in Mysql DB and JSON file.
sample page output is showen below :
(sample.html is the start page )

